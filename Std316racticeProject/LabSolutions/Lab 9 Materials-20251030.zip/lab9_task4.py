from typing import List

def intersecting_chars(my_str):
    pass