from typing import Dict

def add_to_inventory(inventory, product, quality):
    pass