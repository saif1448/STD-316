import doctest

def get_total_revenue(store1_monthly_sales, store2_monthly_sales):
    # add your code here
    return

if __name__ == "__main__":
    doctest.testmod()
