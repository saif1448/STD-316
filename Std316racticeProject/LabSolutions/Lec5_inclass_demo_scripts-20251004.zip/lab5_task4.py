import doctest

def my_food_credit(food_ate, opp_food_ate):
    # add your code here
    return


def opponent_food_credit(opp_food_ate, food_ate):
    # add your code here
    return

if __name__ == "__main__":
    doctest.testmod()
