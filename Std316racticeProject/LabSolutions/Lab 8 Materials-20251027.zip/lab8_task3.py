################################### TASK 3 ###################################
### Starting code ###
def approximate_pi(m):
    result = 0  
    ### Your code here ###  
    
    
    return round(result, 4)
