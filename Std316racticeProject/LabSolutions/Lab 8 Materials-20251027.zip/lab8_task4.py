################################### TASK 4 ###################################
### Starting code ###
def encrypt(message, shift):
    pass
    
